from pathlib import Path

import streamlit as st


APP_DIR = Path(__file__).resolve().parent

navigation = st.navigation(
    [
        st.Page(APP_DIR / "app.py", title="TOPIK II 읽기", icon="📖", default=True),
        st.Page(APP_DIR / "listening_app.py", title="TOPIK II 듣기", icon="🎧"),
        st.Page(APP_DIR / "bulk_generation_app.py", title="50문제 일괄 생성", icon="✨"),
        st.Page(APP_DIR / "topic_bank_app.py", title="소재 은행", icon="🗂️"),
        st.Page(APP_DIR / "direct_publish_app.py", title="세트·로컬 등록", icon="📤"),
        st.Page(APP_DIR / "postgres_publish_app.py", title="고급 관리 · PostgreSQL", icon="🗄️"),
        st.Page(APP_DIR / "backup_restore_app.py", title="백업·복원", icon="💾"),
    ],
    position="sidebar",
)
navigation.run()
