"""Local batch registration, validation, and persistent receipts."""
import os
from pathlib import Path

from dotenv import load_dotenv
import streamlit as st

from topik_question_lab.direct_publication import DirectPublicationService, PublicationBlocked
from topik_question_lab.publication import default_primary_skill

ROOT = Path(os.getenv("TOPIK_LAB_ROOT", str(Path(__file__).resolve().parents[1]))).resolve()
load_dotenv(ROOT / ".env")
st.set_page_config(page_title="세트·로컬 등록", page_icon="📤", layout="wide")
st.title("세트·로컬 등록")
st.caption("생성 묶음별 읽기·듣기 50문항을 검증하고 로컬 PostgreSQL 문항 은행에 등록합니다.")
target_url = os.getenv("DATABASE_URL", "").strip()
try:
    service = DirectPublicationService(ROOT, target_url)
except (PublicationBlocked, OSError) as exc:
    st.error(str(exc))
    st.stop()
if not target_url:
    st.info(".env에 DATABASE_URL을 설정하세요. 로컬 PostgreSQL 연결이 필요합니다.")

try:
    batches = service.list_batches()
except (PublicationBlocked, OSError) as exc:
    st.error(str(exc))
    batches = []

labels = {b["id"]: f"{'읽기' if b['section'] == 'reading' else '듣기'} · {b['model']} · {b['created_at']} UTC · {b['id'][:8]}" for b in batches}
if not batches:
    st.info("일괄 생성한 묶음이 없습니다. ‘50문제 일괄 생성’에서 먼저 생성하세요. 기존 유형별 문항은 고급 관리에서 발행할 수 있습니다.")
else:
    st.dataframe([{"영역": "읽기" if b["section"] == "reading" else "듣기", "모델": b["model"],
                   "생성 시각 (UTC)": b["created_at"], "문항": f"{b['count']}/50", "승인": b["approved"],
                   "로컬 등록": b["publication_status"], "안내": b["reason"]} for b in batches],
                 hide_index=True, width="stretch")
    linked = st.session_state.pop("publication-batch-link", None)
    if linked and linked in labels:
        st.session_state["publication-selection"] = [linked]
    selected = st.multiselect("등록할 세트", list(labels), format_func=labels.get, key="publication-selection")
    metadata = {"level": 4, "difficulty": 0.0, "items": {}}
    if selected:
        catalog = service.catalog()
        candidates = [r.candidate for r in catalog.records if r.candidate.batch_id in selected]
        selected_batches = [b for b in batches if b["id"] in selected]
        for b in selected_batches:
            if b["reason"]:
                st.error(f"{labels[b['id']]}: {b['reason']}")
        with st.expander("문항 미리보기·세부 설정"):
            level = st.selectbox("기본 TOPIK 급수", [3, 4, 5, 6], index=1)
            difficulty = st.number_input("기본 예상 난이도", min_value=-3.0, max_value=3.0, value=0.0, step=0.1)
            rows = [{"source_key": c.source_key, "영역": c.section, "번호": c.slot,
                     "target_level": level, "predicted_difficulty": difficulty,
                     "primary_skill": default_primary_skill(c)} for c in sorted(candidates, key=lambda c: (c.section, c.slot))]
            edited = st.data_editor(rows, hide_index=True, width="stretch",
                disabled=["source_key", "영역", "번호"],
                column_config={"source_key": None,
                    "target_level": st.column_config.NumberColumn("급수", min_value=3, max_value=6, required=True),
                    "predicted_difficulty": st.column_config.NumberColumn("예상 난이도", min_value=-3.0, max_value=3.0, required=True),
                    "primary_skill": st.column_config.TextColumn("Skill", required=True)},
                key=f"publication-metadata-{','.join(sorted(selected))}-{level}-{difficulty}")
            rows = edited.to_dict("records") if hasattr(edited, "to_dict") else edited
            metadata = {"level": level, "difficulty": difficulty,
                        "items": {r["source_key"]: {k: r[k] for k in ("target_level", "predicted_difficulty", "primary_skill")} for r in rows}}
    signature = {"selected": sorted(selected), "metadata": metadata, "target": service.target}
    if st.button("선택 세트 검증", disabled=not selected or not target_url, type="primary"):
        try:
            with st.spinner("문항과 로컬 DB 호환성 확인 중…"):
                job = service.prepare(selected, metadata)
            st.session_state["publication-plan"] = job["id"]
            st.session_state["publication-plan-signature"] = signature
        except (ValueError, OSError) as exc:
            st.session_state.pop("publication-plan", None)
            st.error(str(exc))
    plan_id = st.session_state.get("publication-plan")
    if plan_id and st.session_state.get("publication-plan-signature") == signature:
        job = service.jobs.get(plan_id)
        st.success(f"검증 완료 · {len(selected)}세트 · {len(selected) * 50}문항")
        st.caption(f"고정 작업 ID: {plan_id[:16]} · 선택한 세트를 하나의 트랜잭션으로 등록합니다.")
        if st.button("선택 세트 로컬 등록", type="primary", disabled=job["status"] == "succeeded"):
            try:
                with st.spinner("등록 및 원격 조회 검증 중…"):
                    result = service.publish(plan_id)
                if result["status"] == "succeeded":
                    st.session_state["publication-result"] = plan_id
                    st.rerun()
                else:
                    st.warning("결과 확인 필요: 아래 등록 이력에서 등록 결과를 다시 확인하세요.")
            except (ValueError, OSError) as exc:
                st.error(str(exc))
    elif plan_id:
        st.info("선택·설정이 변경되었습니다. 선택 세트를 다시 검증하세요.")

st.subheader("등록 이력·결과 확인")
st.caption("등록 완료는 문항 은행 반영을 뜻합니다. 음원·그림 파일의 완성 여부는 고급 관리의 로컬 검증에서 확인하세요.")
for job in service.jobs.list():
    current_target = bool(service.target) and job["target"] == service.target
    status = {"prepared": "검증 완료", "publishing": "결과 확인 필요", "outcome_unknown": "결과 확인 필요",
              "succeeded": "등록 완료", "failed": "재시도 가능", "conflict": "충돌", "stale": "재검증 필요"}.get(job["status"], job["status"])
    with st.expander(f"{job['created_at']} UTC · {status} · {job['id'][:12]}{'' if current_target else ' · 이전 DB · 조회 전용'}", expanded=job["status"] in {"succeeded", "outcome_unknown", "conflict"}):
        st.write(" / ".join(labels.get(p["batch_id"], p["batch_id"]) for p in job["payload"]["packages"]))
        if job["message"]:
            st.warning(job["message"])
        if job["result"].get("sets"):
            st.dataframe(job["result"]["sets"], hide_index=True, width="stretch")
        if st.button("등록 결과 다시 확인", key=f"reconcile-{job['id']}", disabled=not target_url or not current_target):
            try:
                service.reconcile(job["id"])
                st.rerun()
            except (ValueError, OSError) as exc:
                st.error(str(exc))
        if current_target and job["status"] in {"failed", "publishing", "outcome_unknown"}:
            if st.button("같은 작업 재시도", key=f"retry-{job['id']}", disabled=not target_url or not current_target):
                try:
                    service.publish(job["id"])
                    st.rerun()
                except (ValueError, OSError) as exc:
                    st.error(str(exc))
