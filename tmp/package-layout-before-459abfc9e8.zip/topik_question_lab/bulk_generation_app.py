from __future__ import annotations

import json
import os
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv

ROOT = Path(os.getenv("TOPIK_LAB_ROOT", str(Path(__file__).resolve().parents[1]))).resolve()
load_dotenv(ROOT / ".env")

from topik_question_lab.bulk_generation import BulkRunner, custom_model, model_options, prepare_batch, profiles_for
from topik_question_lab.providers import (
    DEFAULT_GENERATION_PRESET, GENERATION_PRESETS, can_gateway_call, generation_parameter_preview,
    has_chatkhu_api_key, list_chatkhu_models, provider_backend, provider_label, supports_generation_presets,
)


@st.cache_resource
def get_runner(root: str):
    return BulkRunner(Path(root))


def model_label(value):
    provider, model = value
    backend = "DeepSeek" if provider_backend(provider, model) == "deepseek" else "ChatKHU"
    return f"{provider_label(provider)} · {model} · {backend}"


st.set_page_config(page_title="50문제 일괄 생성", page_icon="✨", layout="wide")
st.title("50문제 일괄 생성")
st.caption("모델과 프리셋을 한 번 선택해 듣기 또는 읽기 50문제 전체에 적용합니다. 생성 결과는 검수 전 초안으로 저장됩니다.")
runner = get_runner(str(ROOT))
runner.recover_idle()
store = runner.store
settings = store.settings()
options = model_options(ROOT)
for model in json.loads(settings.get("extra_models", "[]")):
    try:
        options.append(custom_model(model))
    except ValueError:
        pass
options = list(dict.fromkeys(options))
saved = tuple(json.loads(settings.get("last_model", '["gpt_5_6_luna","gpt-5.6-luna"]')))
if "bulk-model" not in st.session_state:
    st.session_state["bulk-model"] = saved if saved in options else options[0]
selected = st.selectbox("모델", options, format_func=model_label, key="bulk-model")
provider, model = selected
store.set_setting("last_model", json.dumps(selected))
presets = json.loads(settings.get("presets", "{}"))
supported = supports_generation_presets(provider, model)
saved_preset = presets.get(model, DEFAULT_GENERATION_PRESET)
if saved_preset not in GENERATION_PRESETS:
    saved_preset = DEFAULT_GENERATION_PRESET
preset_key = f"bulk-preset-{model}"
if preset_key not in st.session_state:
    st.session_state[preset_key] = saved_preset
preset_id = st.selectbox(
    "생성 프리셋", list(GENERATION_PRESETS),
    format_func=lambda value: GENERATION_PRESETS[value].label, disabled=not supported,
    key=preset_key,
)
preset = preset_id if supported else None
if supported:
    presets[model] = preset_id
    store.set_setting("presets", json.dumps(presets))
    st.caption(GENERATION_PRESETS[preset_id].description)
else:
    st.caption("프리셋 미지원 · 기본 API 설정")
st.caption(f"실제 모델 ID: {model} · API {'연결됨' if can_gateway_call(provider) else '키 없음'}")
with st.expander("적용 API 설정"):
    st.json(generation_parameter_preview(provider, model, preset))
with st.expander("모델 목록 관리"):
    if st.button("ChatKHU 모델 동기화", disabled=not has_chatkhu_api_key()):
        try:
            ids = list_chatkhu_models()
            store.set_setting("extra_models", json.dumps(list(dict.fromkeys([*json.loads(settings.get("extra_models", "[]")), *ids]))))
            st.rerun()
        except Exception as exc:
            st.error(str(exc))
    custom = st.text_input("텍스트 모델 ID 직접 추가")
    if st.button("모델 추가", disabled=not custom.strip()):
        try:
            added = custom_model(custom)
            store.set_setting("extra_models", json.dumps(list(dict.fromkeys([*json.loads(settings.get("extra_models", "[]")), added[1]]))))
            st.rerun()
        except ValueError as exc:
            st.error(str(exc))


STATUS_LABELS = {"pending": "대기", "processing": "생성 중", "succeeded": "저장 완료",
                 "failed": "실패", "partial": "일부 완료", "interrupted": "중단 · 재개 가능", "running": "실행 중"}


@st.fragment(run_every="2s")
def render_progress():
    batches = store.batches()
    signature = tuple((batch["id"], batch["status"]) for batch in batches)
    previous = st.session_state.get("bulk-status-signature")
    st.session_state["bulk-status-signature"] = signature
    if previous is not None and previous != signature:
        # Refresh start buttons and the next batch's preflight after completion.
        st.rerun()
    if not batches:
        return
    st.subheader("생성 진행과 실행 이력")
    selected_id = st.selectbox(
        "생성 묶음", [batch["id"] for batch in batches], key="bulk-history",
        format_func=lambda value: next(
            f"{'듣기' if batch['section'] == 'listening' else '읽기'} · {batch['created_at']} UTC · {batch['model']} · {value[:8]}"
            for batch in batches if batch["id"] == value),
    )
    batch = next(value for value in batches if value["id"] == selected_id)
    tasks = store.tasks(selected_id)
    count = sum(task["count"] for task in tasks)
    reviews = sum(task["review_count"] for task in tasks)
    st.progress(count / 50, text=f"{STATUS_LABELS[batch['status']]} · 저장 {count}/50 · 검사 지적 문항 {reviews}")
    st.caption(f"고정 모델: {batch['model']} · 고정 프리셋: {GENERATION_PRESETS[batch['preset']].label if batch['preset'] else '기본 API 설정'}")
    st.dataframe([{"번호": ", ".join(map(str, task["snapshot"]["slots"])), "유형": task["type_id"],
                   "상태": STATUS_LABELS[task["status"]], "저장": task["count"],
                   "검사 지적": task["review_count"], "시도": task["attempts"], "안내": task["error"]}
                  for task in tasks], hide_index=True, use_container_width=True)
    if batch["error"]:
        st.error(batch["error"])
    if batch["status"] == "succeeded":
        st.success("1~50번 저장이 완료되었습니다. 검수·승인 후 ‘세트·로컬 등록’에서 로컬 PostgreSQL 문항 은행에 등록하세요.")
        if st.button("이 묶음 세트·로컬 등록", key="bulk-open-publication"):
            st.session_state["publication-batch-link"] = selected_id
            st.switch_page(str(Path(__file__).resolve().parent / "direct_publish_app.py"))
    busy = any(value["status"] == "running" for value in batches)
    if st.button("실패·미완료 유형 재시도", disabled=busy or batch["status"] == "succeeded", key="bulk-resume"):
        try:
            runner.start(batch_id=selected_id)
            st.rerun()
        except Exception as exc:
            st.error(str(exc))


listening_tab, reading_tab = st.tabs(["듣기 50문제", "읽기 50문제"])
for section, tab in (("listening", listening_tab), ("reading", reading_tab)):
    with tab:
        label = "듣기" if section == "listening" else "읽기"
        type_count = len(profiles_for(section))
        st.caption(f"{type_count}개 유형을 순서대로 실행합니다. 문제·보기·정답·해설과 필요한 대본·이미지 설명을 생성합니다.")
        if st.button("준비 상태 새로 확인", key=f"bulk-refresh-{section}"):
            st.session_state.pop(f"bulk-plan-{section}", None)
        files = list((ROOT / "data/types").glob("*.db")) if section == "reading" else list((ROOT / "data/listening/types").glob("*.db"))
        topic_path = ROOT / "data/topic_bank.db"
        signature = (provider, model, preset, tuple((str(path), path.stat().st_mtime_ns) for path in sorted(files)),
                     topic_path.stat().st_mtime_ns if topic_path.exists() else 0)
        cached = st.session_state.get(f"bulk-plan-{section}")
        if cached is None or cached[0] != signature:
            snapshots, errors = prepare_batch(ROOT, section, provider, model, preset)
            cached = (signature, snapshots, errors)
            st.session_state[f"bulk-plan-{section}"] = cached
        _, snapshots, errors = cached
        st.dataframe([{"번호": ", ".join(map(str, item["slots"])), "유형": item["type_id"],
                       "문항 수": item["count"], "승인 예시": item["approved_count"], "난이도": item["difficulty"]}
                      for item in snapshots], hide_index=True, use_container_width=True)
        for error in errors:
            st.error(error)
        busy = any(batch["status"] == "running" for batch in store.batches())
        if st.button(f"{label} 50문제 생성", type="primary", disabled=bool(errors) or busy, key=f"bulk-start-{section}"):
            try:
                batch_id = runner.start(snapshots)
                st.session_state["bulk-history"] = batch_id
                st.rerun()
            except Exception as exc:
                st.error(str(exc))

render_progress()
