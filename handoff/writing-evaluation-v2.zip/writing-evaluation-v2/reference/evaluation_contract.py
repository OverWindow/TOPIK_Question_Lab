"""Current Hub request/scoring contract, packaged without provider or storage dependencies."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, StrictInt

from .writing_models import WritingQuestion, WritingReference


OPERATION = "writing_evaluation"
EVALUATION_INPUT_VERSION = 2
SCORE_LIMITS = {
    51: {"a": 5, "b": 5}, 52: {"a": 5, "b": 5},
    53: {"content": 7, "organization": 7, "language": 16},
    54: {"content": 12, "organization": 12, "language": 26},
}
SCORE_LABELS = {"a": "㉠", "b": "㉡", "content": "내용 및 과제 수행",
                "organization": "글의 전개 구조", "language": "언어 사용"}


class EvaluationModel(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class LearnerAnswer(EvaluationModel):
    # Preserve whitespace and wording in the submitted answer and evidence quotes.
    a: str = Field(default="", max_length=2000)
    b: str = Field(default="", max_length=2000)
    text: str = Field(default="", max_length=20000)

    def for_slot(self, slot: int) -> dict[str, str]:
        if slot not in SCORE_LIMITS:
            raise ValueError("51~54번 문항만 평가할 수 있습니다.")
        if (slot < 53 and self.text) or (slot >= 53 and (self.a or self.b)):
            raise ValueError("문항 유형에 맞는 답안 필드를 사용하세요.")
        return {"a": self.a, "b": self.b} if slot < 53 else {"text": self.text}


class CriterionScore(EvaluationModel):
    score: int = Field(ge=0, le=26, description="언어 사용은 2배 적용 후 짝수 점수")
    rationale: str = Field(min_length=1)
    quotes: list[str] = Field(default_factory=list, description="학습자 원본 답안에서 그대로 인용")
    parts: dict[Literal["content", "form"], StrictInt] = Field(default_factory=dict,
        description="현재 평가는 빈 객체. 기존 기록 조회 시에만 출처가 있는 빈칸 세부 배점을 허용")


class TaskCheck(EvaluationModel):
    requirement_id: str = Field(min_length=1)
    status: Literal["충족", "부분 충족", "미충족"]
    reason: str = Field(min_length=1)
    quotes: list[str] = Field(default_factory=list)


class Correction(EvaluationModel):
    original: str = Field(min_length=1)
    suggestion: str = Field(min_length=1)
    reason: str = Field(min_length=1)


class EvaluationResult(EvaluationModel):
    request_id: str = Field(pattern=r"^[0-9a-f]{64}$")
    type_slot: Literal[51, 52, 53, 54]
    scores: dict[Literal["a", "b", "content", "organization", "language"], CriterionScore]
    task_checks: list[TaskCheck]
    corrections: list[Correction] = Field(default_factory=list)
    summary: str = Field(min_length=1)
    review_reasons: list[str] = Field(default_factory=list)

    @property
    def total(self) -> int:
        return sum(item.score for item in self.scores.values())


def digest(value) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def character_counts(text: str) -> dict:
    # This is a reproducible text count, not a simulation of manuscript-paper cells.
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    return {
        "공백_포함_줄바꿈_제외": len(normalized.replace("\n", "")),
        "모든_공백_제외": sum(not char.isspace() for char in normalized),
        "계산_방식": "Unicode 코드 포인트 수. 원고지 칸 수·공식 글자 수와 다를 수 있으며 자동 감점에 사용하지 않음.",
    }


def evaluation_tasks(question: WritingQuestion) -> dict[str, str]:
    if question.type_slot < 53:
        return {"a": "㉠의 문맥·의미·문법·격식", "b": "㉡의 문맥·의미·문법·격식"}
    if question.type_slot == 54:
        return {f"requirement:{i}": value for i, value in enumerate(question.requirements, 1)}
    return {
        **{f"material:{i}": f"자료의 정보와 관계: {value.title}" for i, value in enumerate(question.materials, 1)},
        **{f"note:{i}": value for i, value in enumerate(question.material_notes, 1)},
    }


@dataclass(frozen=True)
class EvaluationRequest:
    system: str
    user: str
    request_id: str

    @property
    def payload(self) -> dict:
        return json.loads(self.user)


def build_evaluation_request(reference: WritingReference | WritingQuestion, answer: LearnerAnswer, *,
                             system: str, rubric: dict, notes: str = "",
                             source_key: str | None = None) -> EvaluationRequest:
    if not system.strip():
        raise ValueError("평가 시스템 프롬프트를 입력하세요.")
    if isinstance(reference, WritingReference):
        question, question_payload, source_key = reference.question, reference.model_dump(), reference.source_key
    else:
        if not isinstance(source_key, str) or not source_key.strip():
            raise ValueError("운용 문항의 실제 식별자 source_key가 필요합니다.")
        question = reference
        question_payload = {"question": question.model_dump(), "source_instruction": question.instruction}
    slot = question.type_slot
    original = answer.for_slot(slot)
    payload = {
        "source_key": source_key, "type_slot": slot,
        "question": question_payload, "answer": original,
        "rubric": rubric,
        "experimental_notes": notes,
        "tasks": evaluation_tasks(question),
        "character_counts": {key: character_counts(value) for key, value in original.items()},
        "score_limits": SCORE_LIMITS[slot],
        "output_schema": EvaluationResult.model_json_schema(),
    }
    if slot < 53:
        # Substitute simultaneously so learner text cannot introduce a second replacement.
        import re
        payload["completed_passage"] = re.sub(
            r"\((㉠|㉡)\)", lambda match: original["a" if match[1] == "㉠" else "b"], question.passage)
    request_id = digest({"system": system, "payload": payload})
    payload["request_id"] = request_id
    return EvaluationRequest(system, json.dumps(payload, ensure_ascii=False, indent=2), request_id)


def validate_scores(slot: int, scores: dict[str, int]) -> None:
    limits = SCORE_LIMITS[slot]
    if set(scores) != set(limits):
        raise ValueError("문항 유형에 맞는 평가 영역이 필요합니다.")
    for key, value in scores.items():
        if type(value) is not int or not 0 <= value <= limits[key]:
            raise ValueError(f"{SCORE_LABELS[key]} 점수 범위는 0~{limits[key]}입니다.")
    if slot >= 53 and scores["language"] % 2:
        raise ValueError("2017 기준의 언어 사용 점수는 원점수에 2를 곱한 짝수여야 합니다.")


def validate_response(response: dict, request: EvaluationRequest) -> EvaluationResult:
    if "reference_answer" in request.payload:
        raise ValueError("v2 요청에는 참고답안을 포함할 수 없습니다.")
    parsed = EvaluationResult.model_validate(response)
    payload = request.payload
    slot = payload["type_slot"]
    if parsed.request_id != request.request_id or parsed.type_slot != slot:
        raise ValueError("평가 응답이 현재 문항·답안·프롬프트와 일치하지 않습니다. 현재 요청으로 다시 평가하세요.")
    validate_scores(slot, {key: item.score for key, item in parsed.scores.items()})
    original = payload["answer"]
    texts = list(original.values())
    # Old saved responses retain their original per-blank scoring contract.
    weights = payload.get("reference_answer", {}).get("blank_weights", {})
    for key, item in parsed.scores.items():
        relevant = [original[key]] if slot < 53 else texts
        if not any(text.strip() for text in relevant) and item.score:
            raise ValueError("미응답에는 점수를 부여할 수 없습니다.")
        if item.score and not item.quotes:
            raise ValueError("점수를 부여한 영역에는 원본 답안 인용이 필요합니다.")
        if any(not quote.strip() or not any(quote in text for text in relevant) for quote in item.quotes):
            raise ValueError("평가 근거 인용이 원본 답안에 없습니다.")
        expected = weights.get(key, {})
        if set(item.parts) != set(expected):
            raise ValueError("출처의 빈칸 세부 배점에 맞는 내용·형식 점수가 필요합니다.")
        if expected and (any(not 0 <= value <= expected[part] for part, value in item.parts.items())
                         or sum(item.parts.values()) != item.score):
            raise ValueError("빈칸 세부 점수의 범위 또는 합계가 맞지 않습니다.")
    task_ids = [check.requirement_id for check in parsed.task_checks]
    if len(task_ids) != len(set(task_ids)) or set(task_ids) != set(payload["tasks"]):
        raise ValueError("모든 과제의 수행 여부를 중복 없이 확인해야 합니다.")
    for check in parsed.task_checks:
        if check.status != "미충족" and not check.quotes:
            raise ValueError("충족한 과제에는 원본 답안 인용이 필요합니다.")
        relevant = [original[check.requirement_id]] if slot < 53 else texts
        if any(not quote.strip() or not any(quote in text for text in relevant) for quote in check.quotes):
            raise ValueError("과제 수행 인용이 원본 답안에 없습니다.")
    for correction in parsed.corrections:
        if not correction.original.strip() or not any(correction.original in text for text in texts):
            raise ValueError("수정 대상으로 인용한 표현이 원본 답안에 없습니다.")
    return parsed


def build_request(source_key: str, question: dict, answer: dict, *,
                  package_root: Path | None = None) -> EvaluationRequest:
    root = package_root or Path(__file__).resolve().parents[1]
    parsed_question = WritingQuestion.model_validate(question)
    slot = parsed_question.type_slot
    system = (root / f"prompts/{slot}.txt").read_text(encoding="utf-8")
    rubrics = json.loads((root / "rubrics.json").read_text(encoding="utf-8"))
    return build_evaluation_request(parsed_question, LearnerAnswer.model_validate(answer),
        system=system, rubric=rubrics[str(slot)], source_key=source_key, notes="")


def empty_response(request: EvaluationRequest) -> dict | None:
    payload = request.payload
    if "reference_answer" in payload:
        raise ValueError("v2 요청에는 참고답안을 포함할 수 없습니다.")
    if any(value.strip() for value in payload["answer"].values()):
        return None
    return EvaluationResult(
        request_id=request.request_id, type_slot=payload["type_slot"],
        scores={key: CriterionScore(score=0, rationale="미응답") for key in SCORE_LIMITS[payload["type_slot"]]},
        task_checks=[TaskCheck(requirement_id=key, status="미충족", reason="미응답") for key in payload["tasks"]],
        summary="작성된 답안이 없어 0점으로 처리했습니다.",
    ).model_dump()
