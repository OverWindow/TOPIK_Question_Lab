# TOPIK PostgreSQL 문항 은행

이 문서는 `006_unversioned_items` 이후의 코드와 스키마를 설명합니다.
로컬 생성기는 `DATABASE_URL`의 PostgreSQL만 사용합니다.
기존 DB의 구조 전환은 [이관 안내](docs/UNVERSIONED_DATABASE_MIGRATION.md)를 따릅니다.

## 저장 원칙

- 문제 하나는 고정된 `item_id`와 현재 내용 한 행을 갖습니다. 문항 버전 번호는 없습니다.
- 명시적인 문항 동기화는 같은 행을 갱신합니다. 과거 수정 내용은 보존하지 않습니다.
- 한 문제는 최대 한 세트에 속하며, 미배정 문제의 `set_id`, `position`은 모두 `NULL`입니다.
- 세트는 `items.set_id`, `items.position`으로 구성합니다. 문제 갱신은 해당 세트의 조회 결과에도 반영됩니다.
- 핵심 테이블은 `items`, `question_sets`입니다. 생성·검수·프롬프트·소재·작업·배포 보조 저장소는 유지합니다.
- 프롬프트 저장 이력과 모델 정보는 문항 수정 버전과 별개입니다. `prompt_version`은 프롬프트 해시이고, 기존 이름 `generator_version`은 모델 ID입니다.

## 기존 생성 흐름

유형·모델 선택 → 프롬프트 구성 → API 생성 또는 웹 응답 수동 입력 → 자동 검증 → 검수·수정 → 세트 구성 → 수동 발행 순서를 유지합니다.
읽기·듣기 생성 화면, SQLite 생성·검수 저장, 50문항 일괄 생성, 소재 은행, 파일 내보내기와 백업은 유지합니다.
PostgreSQL 연결이 없어도 기존 생성 기능을 사용할 수 있습니다.

## 테이블과 뷰

### `topik_bank.items`

기존 `items`에 문항 내용과 세트 소속을 통합합니다.

| 필드 | 의미 |
| --- | --- |
| `item_id` | 문제 UUID, 기본 키 |
| `source_key` | 로컬 문제 식별자, 유일 값 |
| `section`, `type_slot`, `item_type` | 영역, TOPIK 번호 유형, 문제 유형 |
| `primary_skill`, `target_level` | 평가 요소와 급수 |
| `stem`, `choices`, `correct_answer`, `explanation` | 지문·질문, 보기, 정답, 해설 |
| `stem_length`, `choice_count` | 지문 길이와 보기 수 |
| `content_json` | 공통 지문·대본·그림 설명을 포함한 전체 문항 |
| `generator_provider`, `generator_model`, `generator_version` | 기존 생성 백엔드·공급자 키·모델 ID |
| `prompt_version` | 생성에 사용한 프롬프트 해시 |
| `review_status` | reviewed / pilot / active / retired |
| `source_provenance` | 원본 DB, 문제·실행 ID, 생성 옵션, `publication_metadata.predicted_difficulty` |
| `content_hash` | 현재 내용·메타데이터의 동일 여부를 판단하는 해시 |
| `set_id`, `position` | 소속 세트 FK와 세트 내 1~50번 순서, 미배정 시 모두 NULL |
| `created_at`, `updated_at` | 최초 저장 시각과 현재 내용 갱신 시각 |

`UNIQUE(set_id, position)`으로 세트 내 번호 중복을 막습니다.
`set_id`와 `position`은 함께 설정되거나 함께 비어 있어야 합니다.
문제 ID가 기본 키이므로 한 문제를 여러 세트에 연결할 수 없습니다.

### `topik_bank.question_sets`

세트 UUID, 영역, 생성 모델 정보, `set_sequence`, 검수 상태,
기본 급수·난이도, 생성·발행 시각을 저장합니다.
같은 영역·모델의 세트 번호는 중복될 수 없습니다.
문항·세트 버전과 버전 기반 `set_fingerprint`는 저장하지 않습니다.
검증과 재시도에는 실제 내용·소속·순서와 작업 스냅샷 해시를 사용합니다.

### 보조 저장소

`schema_migrations`, `deployment_runs`, `deployment_run_sets`는 유지합니다.
로컬 SQLite의 `examples`, `settings`, `prompt_versions`, `runs`, `generated_questions`,
`reviews`, 생성 완료 기록, 소재·사용 이력, 일괄 작업 및 원격 등록 작업도 유지합니다.

### 조회 뷰

`current_items`와 `current_set_contents` 이름은 유지하지만 `item_version` 컬럼은 제거합니다.

```sql
SELECT * FROM topik_bank.current_items
WHERE review_status IN ('reviewed', 'pilot', 'active');

SELECT * FROM topik_bank.current_set_contents
WHERE set_id = '세트 UUID'
ORDER BY position;
```

두 뷰는 현재 내용만 반환합니다. 과거 응시 문제는 Web의 `session_items.question_snapshot`으로 재현합니다.

## 로컬 등록과 검증

`세트·로컬 등록`과 `고급 관리 · PostgreSQL`은 모두 `DATABASE_URL`을 사용합니다.
미디어는 로컬 파일 또는 S3·CloudFront 설정으로 검증합니다.
저장 위치와 검증 조건은 [로컬 미디어 검증 안내](docs/LOCAL_MEDIA_DEPLOYMENT.md)를 참고하세요.

### 생성 묶음 등록

50문항의 승인, 자동 검사, 번호 분포와 공통 지문을 확인한 다음 한 트랜잭션으로 등록합니다.
작업 내용과 대상 식별자는 `data/publication_jobs.db`에 저장합니다.
동일 내용의 재시도는 기존 세트를 재사용하고, 다른 내용·출처·순서는 충돌로 차단합니다.
등록 후 별도 연결에서 실제 조회 뷰를 검증하며, 결과 재확인과 재시도를 지원합니다.
등록 단계는 DDL이나 마이그레이션을 실행하지 않습니다.

이전 DB 대상의 작업도 이력에서 볼 수 있지만 조회 전용이며 다시 전송하지 않습니다.

### 고급 관리

문항 동기화는 같은 `item_id`의 현재 내용을 갱신합니다.
동일한 문항·순서의 세트는 기존 세트를 갱신하고, 미사용 문항 세트는 새 번호로 발행합니다.
로컬 DB의 `deployment_runs`, `deployment_run_sets`는 과거 기록으로 보존합니다.
발행 이력 탭에서 기존 배포 작업과 세트 발행 이력을 조회할 수 있습니다.

미디어 메타데이터와 연결은 기존 4개 테이블에 유지합니다.
`로컬 검증`은 선택 세트, 필수 음원·이미지, 파일 크기·SHA-256을 읽기 전용으로 검사합니다.
로컬 파일 모드는 기존 주소를 보존합니다. S3·CloudFront 모드는 이관한 파일의 실제 바이트도 검사합니다.
[로컬 미디어 검증 안내](docs/LOCAL_MEDIA_DEPLOYMENT.md)를 참고하세요.

## 기존 DB 이관

이관 파일은 `topik_question_lab/migrations/006_unversioned_items.sql`입니다.
전체 DB를 백업하고 별도 임시 DB에 복원하여 구조 전환을 검증한 후 적용하세요.
문항·세트 ID, 순서, 기존 세트 내용과 보조 이력이 보존되었는지 확인합니다.
외부 응시·미디어 테이블이 구 버전 구조를 참조하면 Hub의 이관은 차단됩니다.
이때 외부 참조를 삭제하거나 Hub만으로 강제 이관하지 마세요.

세트 소속 문항은 **세트가 참조하던 버전의 내용**을 남깁니다.
그 문항에 더 최신의 미발행 내용이 있어도 기존 세트 내용을 바꾸지 않습니다.
미배정 문항은 최신 내용만 남깁니다. 나머지 문항 버전은 제거됩니다.
원래 `item_id`, `source_key`, 생성 시각과 세트 ID는 유지합니다.

한 문항의 다중 세트 소속, 내용이 없는 문항, 외부 테이블의 문항 버전·세트 연결 참조가 있으면 이관을 중단합니다.
뷰·기타 참조가 남아 있으면 PostgreSQL의 의존성 검사로 중단합니다. `CASCADE`로 삭제하지 않습니다.
실패한 이관의 DDL과 데이터 변경은 전체 롤백됩니다.
과거 버전 복구는 이관 전 DB 백업으로만 가능합니다.

## 검증

PostgreSQL 통합 테스트는 `TEST_PG_ADMIN_URL`로 명시한 루프백 서버에서
무작위 이름의 임시 DB를 만들고 종료 시 제거합니다.
`.env`의 DB를 테스트 대상으로 사용하지 않습니다.
환경 변수가 없으면 통합 테스트를 건너뜁니다.

```powershell
.\.venv\Scripts\python.exe -m pytest -q tests/test_publication.py tests/test_postgres_inspection.py
.\.venv\Scripts\python.exe -m pytest -q tests/test_unversioned_questions.py tests/test_postgres_integration.py tests/test_media_validation_integration.py tests/test_direct_publication.py
```

합성 데이터로 기존 세트 내용 보존, 미배정 최신 내용 선택, 다중 소속·외부 참조 차단,
동일 ID 갱신, 중복·동시 등록, 전체 롤백, 네트워크 장애 후 복구를 확인합니다.
생성 API는 호출하지 않습니다. 새 HTTP API나 영구 테이블은 추가하지 않습니다.
